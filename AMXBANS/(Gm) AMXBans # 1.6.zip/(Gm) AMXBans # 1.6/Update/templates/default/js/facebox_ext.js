jQuery(document).ready(function($) {
	$('a[rel*=facebox]').facebox()
})