// Author Notes:
// This file has been translated from English to Ukrain by ***Fire*** and nato

// This is the Import / Export's Language File

<? php
define ( "_MENUIMPORTEXPORT", "Імпорт / Експорт");
define ( "_DATAIMPORTEXPORT", "Інформація Імпорт / Експорт");
define ( "_DATABASE", "Зберегти базу даних");
define ( "_BACKUPBANS", "Зберегти бани як. sql файл");
define ( "_LOCALBACKUPS", "Місцеві резервні копії");
define ( "_BANSIEXPORT", "Імпорт / Експорт банів");
define ( "_BACKUPALL", "Зберегти базу даних як. sql файл");
define ( "_BACKUP", "Резервна копія");
define ( "_RESTORE", "Відновити");
define ( "_IMPORT", "Імпорт");
define ( "_EXPORT", "Експорт");
define ( "_ONLYSTRUCTUR", "Зберегти лише структуру");
define ( "_INCLUDEDROP", "Додати DROP TABLE");
define ( "_INCLUDEDELETE", "Додати DELETE FROM");
define ( "_DOWNLOADAFTER", "Завантажити файл після створення");
define ( "_UPLOADBACKUP", "Завантажити резервну копію");
define ( "_BACKUPSUCCESS", "Резервне копіювання завершилося успішно");
define ( "_BACKUPFAILNOFILE", "Резервне копіювання провалилося: Файл не може бути створено!");
define ( "_IMPORTED", "Бани імпортовано");
define ( "_FAILED", "провалено");
define ( "_DELALLIMPORTED", "Видалити всі імпортовані бани");
define ( "_DELETEDBANS", "Кількість видалених банів");
define ( "_DBHOST", "Сервер бази даних");
define ( "_DBUSER", "Логін");
define ( "_DBPASSWORD", "Пароль");
define ( "_DBDATABASE", "База даних");
define ( "_DBTABLE", "Таблиця з банамі");
define ( "_CONCHECK", "Перевірити з'єднання");
define ( "_SET", "Встановити");
define ( "_ONLYPERMANENT", "тільки перманентні бани");
define ( "_DELETELOCALTABLE", "видалити поточні бани перед імпортуванням");
define ( "_SETALLNOTIMPORTED", "Відзначити всі бани як 'не імпортовані'");
define ( "_INCLUDEREASON", "Включити причини банів");
define ( "_EXPORTSUCCESS", "Експорт успішно завершено");
define ( "_EXPORTFAILED", "ПОМИЛКА: Експорт не вдався!");
define ( "_EXPORTED", "Експортованi бани");
define ( "_IN", "в");
define ( "_UPDATEDBANSNOTIMPORTED", "Бани позначені як 'не імпортовані'");
define ( "_DBDATAOK", "Підключення успішно завершено");
define ( "_DBLOGINFAILED", "Не вдалося підключитися до бази даних!");
define ( "_DBSELECTDBFAILED", "База даних не існує!");
define ( "_TABLESSELECTFAILED", "Таблиця не існує!");
define ( "_LOCALTABLEDELETED", "Поточні бани видалені!");
define ( "_TITLEIEXPORT", "Імпорт / Експорт");
// alerts
define ( "_DELBACKUP", "Дійсно видалити цю резервну копію?");
define ( "_DATAIMPORT", "Почати імпортування?");
define ( "_DELIMPORT", "Дійсно видалити імпортовану інформацію?");
define ( "_SETIMPORT", "Імпортована інформація не може бути вилучена окремо!");
//import from/export in
define("_IMP_FILE", "Імпортувати з banned.cfg");
define("_IMP_DB", "Імпортувати з бази даних AMXBans 5.x");
define("_EXP_FILE", "Експортувати з banned.cfg file");
?>